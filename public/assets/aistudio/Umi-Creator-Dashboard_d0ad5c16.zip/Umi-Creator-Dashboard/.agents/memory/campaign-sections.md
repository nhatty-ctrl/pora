---
name: Campaign sections
description: Preserve the campaign discovery, joined, and created sections.
---

Campaigns must keep three separate, working sections: Discover, Joined, and Created.

**Why:** the user explicitly called out when Joined and Created were omitted from the converted UI.

**How to apply:** preserve all three tabs and their respective content states during campaign layout or refactor changes.
